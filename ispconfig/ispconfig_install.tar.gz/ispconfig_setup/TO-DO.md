My to-do list for the ispconfig3 installer script.

 Must have:</br>
  - [x] Fix the script(would be nice hehe)!
  - [x] Check if the slave-server can connect to the master servers database before installing.
  - [ ] Documentation on the cluster setup with this script...
   </br>Nice to Have:
      - [ ] Add Users too mysql-datbase host via sh or pHp script
      - [ ] Add/include the feature to install skin on ispconfig3
      - [ ] Add roundcube with skin to the installer... 
    </br>Maybe some day:
        - [ ] World domination?
        

Suggestions? feel free to comment.
