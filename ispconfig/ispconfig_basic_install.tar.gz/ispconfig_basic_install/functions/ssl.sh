Openssl() {

 	SSL_COUNTRY="EN"
        SSL_STATE="USA"
        SSL_LOCALITY="Texas"
        SSL_ORGANIZATION="DBM"
        SSL_ORGUNIT="IT"

}

