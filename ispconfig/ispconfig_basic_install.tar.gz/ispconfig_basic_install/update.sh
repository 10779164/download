#!/bin/bash

PWD=$(pwd)

# Bash Colour
red='\033[0;31m'
green='\033[0;32m'
NC='\033[0m' # No Color

if [ ! -d "ispconfig3_install" ];then
tar -xvf ISPConfig-3-stable.tar.gz
fi

[ -f /bin/whiptail ] && echo -e "whiptail found: ${green}OK${NC}\n"  || yum -y install newt

Packages=$(whiptail --title "update ispconfig" --backtitle "$WT_BACKTITLE" --nocancel --radiolist "Select you want updated packages" 10 50 2 "MAIL" "(default)" ON "DNS" "" OFF 3>&1 1>&2 2>&3)


if [ $Packages == "MAIL" ];then
  echo "Start updata webmail for ispconfig..."
  source $PWD/distros/centos/install_postfix.sh
  source $PWD/distros/centos/install_webmail.sh

  cd $PWD/ispconfig3_install/install
  [ -f "autoinstall.ini" ] && rm -f autoinstall.ini

  echo "Start update web mail..."
  touch autoinstall.ini
  echo "[update]" >> autoinstall.ini
  echo "svc_detect_change_db_server=no">> autoinstall.ini  
  echo "svc_detect_change_mail_server=yes" >> autoinstall.ini
  echo "do_backup=yes" >> autoinstall.ini
  echo "reconfigure_permissions_in_master_database=no" >> autoinstall.ini
  echo "svc_detect_change_firewall_server=no" >> autoinstall.ini
  echo "reconfigure_services=yes" >> autoinstall.ini
  echo "ispconfig_port=8080" >> autoinstall.ini
  echo "create_new_ispconfig_ssl_cert=no" >> autoinstall.ini
  echo "reconfigure_crontab=yes" >> autoinstall.ini

  InstallPostfix
  InstallWebmail

  php -q update.php --autoinstall=autoinstall.ini
  if [ $? == "0" ];then
  echo -e "${green}ispconfig update successfully...${NC}"
  else
  echo -e "${red}ispconfig update failed...${NC}"
  fi

  else
  echo "Start updata dns for ispconfig..."
  source $PWD/distros/centos/install_bind.sh

  cd $PWD/ispconfig3_install/install
  [ -f "autoinstall.ini" ] && rm -f autoinstall.ini
  echo "[update]" >> autoinstall.ini
  echo "svc_detect_change_db_server=no">> autoinstall.ini
  echo "svc_detect_change_dns_server=yes" >> autoinstall.ini
  echo "do_backup=yes" >> autoinstall.ini
  echo "reconfigure_permissions_in_master_database=no" >> autoinstall.ini
  echo "svc_detect_change_firewall_server=no" >> autoinstall.ini
  echo "reconfigure_services=yes" >> autoinstall.ini
  echo "ispconfig_port=8080" >> autoinstall.ini
  echo "create_new_ispconfig_ssl_cert=no" >> autoinstall.ini
  echo "reconfigure_crontab=yes" >> autoinstall.ini
 
 
  InstallBind

  php -q update.php --autoinstall=autoinstall.ini
  if [ $? == "0" ];then
  echo -e "${green}ispconfig update successfully...${NC}"
  else
  echo -e "${red}ispconfig update failed...${NC}"
  fi

fi
