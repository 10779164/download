#!/bin/bash

PWD=$(pwd)

if [ ! -d "ispconfig3_install" ];then
tar -xvf ISPConfig-3-stable.tar.gz
fi

[ -f /bin/whiptail ] && echo -e "whiptail found: ${green}OK${NC}\n"  || yum -y install newt

Packages=$(whiptail --title "update ispconfig" --backtitle "$WT_BACKTITLE" --nocancel --radiolist "Select you want updated packages" 10 50 2 "MAIL" "(default)" ON "DNS" "" OFF 3>&1 1>&2 2>&3)


if [ $Packages == "MAIL" ];then
  echo "Start updata webmail for ispconfig..."
  source $PWD/distros/centos/install_postfix.sh
  source $PWD/distros/centos/install_webmail.sh

  cd $PWD/ispconfig3_install/install
  [ -f "autoinstall.ini" ] && rm -f autoinstall.ini

  echo "Start update web mail..."
  touch autoinstall.ini
  echo "configure_mail=y" >> autoinstall.ini
  echo "configure_ftp=y" >> autoinstall.ini
  echo "configure_apache=y" >> autoinstall.ini
  echo "configure_firewall=y" >> autoinstall.ini
  echo "install_ispconfig_web_interface=y" >> autoinstall.ini

  InstallPostfix
  InstallWebmail

  php -q update.php --autoinstall=autoinstall.ini
  if [ $? == "0" ];then
  echo "ispconfig update successfully..."
  else
  echo "ispconfig update failed..."
  fi

  else
  echo "Start updata dns for ispconfig..."
  source $PWD/distros/centos/install_bind.sh

  cd $PWD/ispconfig3_install/install
  [ -f "autoinstall.ini" ] && rm -f autoinstall.ini
  echo "configure_dns=y" >> autoinstall.ini
  
  InstallBind

  php -q update.php --autoinstall=autoinstall.ini
  if [ $? == "0" ];then
  echo "ispconfig update successfully..."
  else
  echo "ispconfig update failed..."
  fi

fi
