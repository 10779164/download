#!/bin/bash	
#mail:10779164@qq.com

# Bash Colour
red='\033[0;31m'
green='\033[0;32m'
NC='\033[0m' # No Color

#Saving current directory
PWD=$(pwd)
pwd=$(pwd)


#Load modules
source $PWD/functions/check_linux.sh

source $PWD/distros/centos/install_basics.sh
source $PWD/distros/centos/install_ftp.sh
source $PWD/distros/centos/install_mysql.sh
source $PWD/distros/centos/install_webserver.sh

InstallBasics
InstallSQLServer
InstallWebServer
InstallFTP
InstallISPConfig

echo -e "${green}Well done! ISPConfig basic installed and configured correctly :Successfully! ${NC}"
echo -e "Now you can connect to your ISPConfig installation at ${green}https://$CFG_HOSTNAME_FQDN:8080 or https://IP_ADDRESS:8080${NC}"
echo -e "Your ISPConfig admin's password is:${green}admin${NC}"
