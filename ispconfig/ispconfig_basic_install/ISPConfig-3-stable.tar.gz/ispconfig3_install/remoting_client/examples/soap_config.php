<?php

$username = 'admin';
$password = 'admin1234';

/*
$soap_location = 'http://localhost:8080/ispconfig3_3.0.5/interface/web/remote/index.php';
$soap_uri = 'http://localhost:8080/ispconfig3_3.0.5/interface/web/remote/';
*/


$soap_location = 'https://192.168.1.100:8080/remote/index.php';
$soap_uri = 'https://192.168.1.100:8080/remote/';


?>
